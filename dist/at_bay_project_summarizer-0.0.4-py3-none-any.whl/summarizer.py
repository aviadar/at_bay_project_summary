from transformers import pipeline, AutoTokenizer


class Summarizer:
    def __init__(self, gpu=0):
        tokenizer = AutoTokenizer.from_pretrained("facebook/bart-large-cnn", model_max_len=1024)
        if gpu == 0:
            self.summarizer = pipeline("summarization",
                                       device=0,
                                       model="facebook/bart-large-cnn",
                                       tokenizer=tokenizer)
        else:
            self.summarizer = pipeline("summarization",
                                       model="facebook/bart-large-cnn",
                                       tokenizer=tokenizer)

    def summarize(self, in_text, max_length=130, min_length=30, do_sample=False):
        return self.summarizer(in_text, max_length=max_length, min_length=min_length, do_sample=do_sample)[0]['summary_text']

